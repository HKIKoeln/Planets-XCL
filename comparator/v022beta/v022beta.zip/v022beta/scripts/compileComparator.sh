#! /bin/bash

g++ -I ../../../../../opt/xercesc/include/ -o comparator main.cpp ComparatorInterface.cpp ComparatorError.cpp Comparer.cpp ComparerMeasure.cpp ComparatorOutput.cpp ComparerResults.cpp DataTagset.cpp InputParams.cpp PropertyTagset.cpp Request2InHandler.cpp Request2Input.cpp SaxInterface.cpp timestamp.cpp XCDLHandler.cpp XercesString.cpp XMLValidation.cpp XCDLIndexes.cpp XCDLIndexGenerator.cpp -L ../../../../../opt/xercesc/lib/ -lxerces-c 
