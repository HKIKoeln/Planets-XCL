double cpu_time ( void );
void timestamp ( void );
std::string timestring ( void );
